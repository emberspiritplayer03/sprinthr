<?php
define(DB_HOST, '127.0.0.1');
define(DB_USERNAME, 'root');
define(DB_PASSWORD, '');
define(DB_DATABASE, 'jcc_10302020_db');

/*//REMOTE SERVER
define(REMOTE_DB_HOST, 'sprinthr.com');
define(REMOTE_DB_USERNAME, 'sprinthr_develop');
define(REMOTE_DB_PASSWORD, ']5D@r~4A6!+e');
define(REMOTE_DB_DATABASE, 'sprinthr_v1_beta');*/


/*//REMOTE SERVER
define(REMOTE_DB_HOST, 'sprinthr.apps');
define(REMOTE_DB_USERNAME, 'dev_admin');
define(REMOTE_DB_PASSWORD, '');
define(REMOTE_DB_DATABASE, 'sprinthr_test_portaldb');*/

//REMOTE SERVER
define(REMOTE_DB_HOST, 'globalcircle.biz');
define(REMOTE_DB_USERNAME, 'global_sprinthr');
define(REMOTE_DB_PASSWORD, 'abc123!@#');
define(REMOTE_DB_DATABASE, 'global_sprinthr_development');
?>