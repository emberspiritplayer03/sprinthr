<?php
define(DB_HOST, '127.0.0.1');
define(DB_USERNAME, 'root');
define(DB_PASSWORD, '');
define(DB_DATABASE, 'jcc_10302020_db');

//REMOTE SERVER
define(REMOTE_DB_HOST, 'localhost');
define(REMOTE_DB_USERNAME, 'root');
define(REMOTE_DB_PASSWORD, '');
define(REMOTE_DB_DATABASE, 'sprinthr_daichidb_dev');
?>